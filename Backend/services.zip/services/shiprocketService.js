import axios from "axios";

const SHIPROCKET_BASE_URL =
  "https://apiv2.shiprocket.in/v1/external";

const isTestMode = process.env.SHIPROCKET_MODE === "test";

let cachedToken = null;
let tokenExpiresAt = 0;

/**
 * Get Shiprocket authentication token
 */
const getShiprocketToken = async () => {
  if (isTestMode) {
    return null;
  }

  if (cachedToken && Date.now() < tokenExpiresAt) {
    return cachedToken;
  }

  const response = await axios.post(
    `${SHIPROCKET_BASE_URL}/auth/login`,
    {
      email: process.env.SHIPROCKET_EMAIL,
      password: process.env.SHIPROCKET_PASSWORD,
    },
    {
      headers: {
        "Content-Type": "application/json",
      },
    }
  );

  cachedToken = response.data.token;

  // Shiprocket token is valid for several days.
  tokenExpiresAt = Date.now() + 9 * 24 * 60 * 60 * 1000;

  return cachedToken;
};

/**
 * Headers for Shiprocket API
 */
const getHeaders = async () => {
  const token = await getShiprocketToken();

  return {
    Authorization: `Bearer ${token}`,
    "Content-Type": "application/json",
  };
};

/**
 * 1. SHIPPING RATES
 */
export const getShippingRates = async ({
  pickupPostcode,
  deliveryPostcode,
  weight,
  cod = 0,
}) => {
  /**
   * TEST MODE
   */
  if (isTestMode) {
    return {
      data: {
        available_courier_companies: [
          {
            courier_company_id: 101,
            courier_name: "Test Courier",
            rate: 80,
            etd: "3-5 days",
            estimated_delivery_days: 5,
            cod: 1,
            rating: 4.5,
            charge_weight: weight,
          },
          {
            courier_company_id: 102,
            courier_name: "Test Express",
            rate: 120,
            etd: "1-2 days",
            estimated_delivery_days: 2,
            cod: 1,
            rating: 4.8,
            charge_weight: weight,
          },
        ],
      },
    };
  }

  /**
   * LIVE MODE
   */
  const response = await axios.get(
    `${SHIPROCKET_BASE_URL}/courier/serviceability/`,
    {
      headers: await getHeaders(),
      params: {
        pickup_postcode: pickupPostcode,
        delivery_postcode: deliveryPostcode,
        weight,
        cod,
      },
    }
  );

  return response.data;
};

/**
 * 2. CREATE SHIPMENT
 */
export const createShiprocketOrder = async ({
  order,
  pickupLocation,
}) => {
  /**
   * TEST MODE
   */
  if (isTestMode) {
    return {
      order_id: `TEST-${order.orderNumber}`,
      shipment_id: `TEST-SHIP-${order.orderNumber}`,
    };
  }

  /**
   * LIVE MODE
   */
  const address = order.shippingAddress;

  const payload = {
    order_id: order.orderNumber,

    order_date: new Date(
      order.createdAt || Date.now()
    )
      .toISOString()
      .slice(0, 16)
      .replace("T", " "),

    pickup_location: pickupLocation,

    billing_customer_name: address.name,
    billing_last_name: "",

    billing_address: address.line1,
    billing_address_2: address.line2 || "",

    billing_city: address.city,
    billing_pincode: address.postalCode,
    billing_state: address.state,
    billing_country: address.country || "India",

    billing_email: address.email || "",
    billing_phone: address.phone,

    shipping_is_billing: true,

    order_items: [
      {
        name: order.bookTitle,
        sku: String(order.book),
        units: order.quantity || 1,
        selling_price: order.unitPrice || 0,
      },
    ],

    payment_method:
      order.shipping?.paymentMode === "COD"
        ? "COD"
        : "Prepaid",

    sub_total:
      order.subtotal || order.amount,

    length:
      order.shipping?.length || 10,

    breadth:
      order.shipping?.breadth || 10,

    height:
      order.shipping?.height || 10,

    weight:
      order.shipping?.weight || 0.5,
  };

  const response = await axios.post(
    `${SHIPROCKET_BASE_URL}/orders/create/adhoc`,
    payload,
    {
      headers: await getHeaders(),
    }
  );

  return response.data;
};

/**
 * 3. ASSIGN COURIER / GENERATE AWB
 */
export const assignCourier = async ({
  shipmentId,
  courierId,
  orderNumber,
}) => {
  /**
   * TEST MODE
   */
  if (isTestMode) {
    return {
      response: {
        data: {
          awb_code: `TEST-AWB-${orderNumber}`,
          courier_name: "Test Courier",
        },
      },
    };
  }

  /**
   * LIVE MODE
   */
  const payload = {
    shipment_id: shipmentId,
  };

  if (courierId) {
    payload.courier_id = Number(courierId);
  }

  const response = await axios.post(
    `${SHIPROCKET_BASE_URL}/courier/assign/awb`,
    payload,
    {
      headers: await getHeaders(),
    }
  );

  return response.data;
};

/**
 * 4. SCHEDULE PICKUP
 */
export const schedulePickup = async ({
  shipmentId,
}) => {
  /**
   * TEST MODE
   */
  if (isTestMode) {
    return {
      pickup_scheduled: true,
      message: "Test pickup scheduled",
    };
  }

  /**
   * LIVE MODE
   */
  const response = await axios.post(
    `${SHIPROCKET_BASE_URL}/courier/generate/pickup`,
    {
      shipment_id: shipmentId,
    },
    {
      headers: await getHeaders(),
    }
  );

  return response.data;
};