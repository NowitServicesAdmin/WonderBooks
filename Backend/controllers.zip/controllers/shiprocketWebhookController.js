import Order from "../models/order.js";

export const shiprocketWebhook = async (req, res) => {
  try {
    const {
      awb,
      courier_name,
      current_status,
      shipment_status,
      etd,
    } = req.body;

    console.log(
      "Shiprocket webhook:",
      req.body
    );

    if (!awb) {
      return res.status(400).json({
        success: false,
        message: "AWB missing",
      });
    }

    const order = await Order.findOne({
      "shipping.awbCode": awb,
    });

    if (!order) {
      // Return 200 so Shiprocket does not keep retrying
      return res.status(200).json({
        success: true,
        message: "Order not found",
      });
    }

    order.shipping.courierName =
      courier_name ||
      order.shipping.courierName;

    order.shipping.shiprocketStatus =
      shipment_status ||
      current_status ||
      order.shipping.shiprocketStatus;


    const status =
      String(
        shipment_status ||
        current_status ||
        ""
      ).toUpperCase();


    if (status.includes("PICK")) {
      order.shipping.status = "picked_up";
      order.status = "shipped";
    } else if (status.includes("TRANSIT")) {
      order.shipping.status = "in_transit";
      order.status = "shipped";
    } else if (
      status.includes("OUT FOR DELIVERY")
    ) {
      order.shipping.status =
        "out_for_delivery";

      order.status = "shipped";
    } else if (
      status.includes("DELIVERED")
    ) {
      order.shipping.status =
        "delivered";

      order.status = "delivered";

      order.shipping.deliveredDate =
        new Date().toISOString().split("T")[0];

      order.shipping.deliveredTime =
        new Date().toTimeString().slice(0, 8);
    } else if (
      status.includes("RTO") ||
      status.includes("RETURN")
    ) {
      order.shipping.status =
        status.includes("RTO")
          ? "rto"
          : "returned";
    }

    if (etd) {
      order.shipping.estimatedDelivery =
        etd;
    }

    order.shipping.updatedAt =
      new Date();

    await order.save();

    return res.status(200).json({
      success: true,
    });

  } catch (error) {
    console.error(
      "Shiprocket webhook error:",
      error
    );

    return res.status(500).json({
      success: false,
    });
  }
};